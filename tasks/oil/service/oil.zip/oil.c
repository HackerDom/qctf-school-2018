#include <stdio.h>
#include <stdlib.h>

void print_menu(void) {
    printf("Select your action:\n");
    printf("1. Show current oil reserve on the platform.\n");
    printf("2. Update information about platform.\n");
    printf("3. Export all information.\n");
    printf("4. Exit.\n");
}

void process(void) {
    char platforms[1024];
    int choice;
    int number;
    memset(platforms, 0, 1024);
    printf(".:= Oil Platform Manager =:.\n");

    while (1) {
        print_menu();
        scanf("%d", &choice);

        if (choice == 4)
            break;
        
        if (choice == 3) {
            printf("Save it! %s\n", platforms);
            continue;
        }
        
        if (choice != 1 && choice != 2) {
            printf("Incorrect action!\n");
            continue;
        }
        
        printf("Enter the number of the platform: ");
        scanf("%d", &number);
        if (number < 0 || number > 1024) {
            printf("Incorrect number of the platform!\n");
            continue;
        }

        if (choice == 1)
            printf("Selected platform contains %d oil.\n", (unsigned char)(platforms[number]));

        if (choice == 2) {
            printf("Enter a current oil reserve on the platform: ");
            scanf("%lld", &platforms[number]);
            printf("Platform updated.\n");
        }
    }
}

int main(int argc, char **argv) {
    process();
    return 0;
}
